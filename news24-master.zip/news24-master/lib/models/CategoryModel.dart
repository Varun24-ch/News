class CategoryModel {
  late String categoryName;
}
