package com.example.news24

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
